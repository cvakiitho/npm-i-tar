current.js x 100,502 ops/sec ±0.80% (94 runs sampled)
isFinite.js x 91,315 ops/sec ±0.92% (89 runs sampled)
parseFloat.js x 72,464 ops/sec ±1.17% (91 runs sampled)
